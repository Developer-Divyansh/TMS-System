export interface UserTeam {
  userId: string;
  teamId: string;
  joinedAt: Date;
}