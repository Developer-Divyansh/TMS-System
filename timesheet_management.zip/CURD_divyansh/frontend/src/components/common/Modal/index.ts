export { Modal } from './Modal';
export type { ModalProps } from './Modal';